import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class GUI extends ApplicationWindow {
	private Composite GETBALANCE_COMPOSITE;
	private Composite DorW_COMPOSITE;
	private Composite CHECK_COMPOSITE;
	private Text WELCOME_TEXT;
	private Text BALANCE_NAME_TAXT;
	private Text BALANCE_VALUE_TEXT;
	private int choiceDorW;
	private int choiceNum;
	private int balance = 10000;
	private String key = "666666";
	private Text KEY_NAME_TEXT;
	private Text KEY_VALUE_TEXT;
	
	/**
	 * Create the application window.
	 */
	public GUI() {
		super(null);
		createActions();
		addToolBar(SWT.FLAT | SWT.WRAP);
		addMenuBar();
		addStatusLine();
	}

	/**
	 * Create contents of the application window.
	 * @param parent
	 */
	@Override
	protected Control createContents(Composite parent) {
		Composite MAIN_COMPOSITE = new Composite(parent, SWT.NONE);
		
		WELCOME_TEXT = new Text(MAIN_COMPOSITE, SWT.READ_ONLY | SWT.CENTER);
		WELCOME_TEXT.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		WELCOME_TEXT.setText("Welcome to the ATM");
		WELCOME_TEXT.setBounds(0, 10, 434, 21);
		
		Button GETBALANCE_BUTTON = new Button(MAIN_COMPOSITE, SWT.NONE);
		GETBALANCE_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				MAIN_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				GETBALANCE_COMPOSITE.setVisible(true);
				BALANCE_VALUE_TEXT.setText(Integer.toString(balance));
			}
		});
		GETBALANCE_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		GETBALANCE_BUTTON.setBounds(77, 48, 108, 39);
		GETBALANCE_BUTTON.setText("\u67E5\u8BE2\u4F59\u989D");
		
		Button DEPOSIT_BUTTON = new Button(MAIN_COMPOSITE, SWT.NONE);
		DEPOSIT_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				choiceDorW = 1;
				MAIN_COMPOSITE.setVisible(false);
				GETBALANCE_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(true);
			}
		});
		DEPOSIT_BUTTON.setText("\u5B58\u6B3E");
		DEPOSIT_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		DEPOSIT_BUTTON.setBounds(239, 48, 108, 39);
		
		Button WITHDRAW_BUTTON = new Button(MAIN_COMPOSITE, SWT.NONE);
		WITHDRAW_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				choiceDorW = 2;
				MAIN_COMPOSITE.setVisible(false);
				GETBALANCE_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(true);
			}
		});
		WITHDRAW_BUTTON.setText("\u53D6\u6B3E");
		WITHDRAW_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		WITHDRAW_BUTTON.setBounds(77, 114, 108, 39);
		
		Button EXIT_BUTTON = new Button(MAIN_COMPOSITE, SWT.NONE);
		EXIT_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.exit(0);
			}
		});
		EXIT_BUTTON.setText("\u9000\u51FA");
		EXIT_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		EXIT_BUTTON.setBounds(239, 114, 108, 39);
		
		
		
		// create a composite to check balance
		GETBALANCE_COMPOSITE = new Composite(parent, SWT.NONE);
		GETBALANCE_COMPOSITE.setBounds(0, 0, 434, 186);
		
		BALANCE_NAME_TAXT = new Text(GETBALANCE_COMPOSITE, SWT.READ_ONLY | SWT.CENTER);
		BALANCE_NAME_TAXT.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		BALANCE_NAME_TAXT.setText("\u5F53\u524D\u4F59\u989D");
		BALANCE_NAME_TAXT.setBounds(88, 41, 78, 28);
		
		BALANCE_VALUE_TEXT = new Text(GETBALANCE_COMPOSITE, SWT.BORDER | SWT.READ_ONLY);
		BALANCE_VALUE_TEXT.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		BALANCE_VALUE_TEXT.setBounds(172, 38, 182, 28);
		
		
		Button ENSURE_BUTTON = new Button(GETBALANCE_COMPOSITE, SWT.NONE);
		ENSURE_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GETBALANCE_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(true);
			}
		});
		ENSURE_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		ENSURE_BUTTON.setBounds(163, 102, 98, 41);
		ENSURE_BUTTON.setText("\u786E\u5B9A");

		
		
		// create a composite to deposit or withdraw
		DorW_COMPOSITE = new Composite(parent, SWT.NONE);
		DorW_COMPOSITE.setBounds(0, 0, 434, 186);
		
		Button RMB100_BUTTON = new Button(DorW_COMPOSITE, SWT.NONE);
		RMB100_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GETBALANCE_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(true);
				choiceNum = 100;
			}
		});
		RMB100_BUTTON.setLocation(77, 48);
		RMB100_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		RMB100_BUTTON.setSize(108, 39);
		RMB100_BUTTON.setText("\u00A5100");
		
		Button RMB300_BUTTON = new Button(DorW_COMPOSITE, SWT.NONE);
		RMB300_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GETBALANCE_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(true);
				choiceNum = 300;
			}
		});
		RMB300_BUTTON.setLocation(239, 48);
		RMB300_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		RMB300_BUTTON.setSize(108, 39);
		RMB300_BUTTON.setText("\u00A5300");
		
		Button RMB500_BUTTON = new Button(DorW_COMPOSITE, SWT.NONE);
		RMB500_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GETBALANCE_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(true);
				choiceNum = 500;
			}
		});
		RMB500_BUTTON.setLocation(77, 114);
		RMB500_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		RMB500_BUTTON.setSize(108, 39);
		RMB500_BUTTON.setText("\u00A5500");
		
		Button RMB1000_BUTTON = new Button(DorW_COMPOSITE, SWT.NONE);
		RMB1000_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				GETBALANCE_COMPOSITE.setVisible(false);
				DorW_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(true);
				choiceNum = 1000;
			}
		});
		RMB1000_BUTTON.setLocation(239, 114);
		RMB1000_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		RMB1000_BUTTON.setSize(108, 39);
		RMB1000_BUTTON.setText("\u00A51000");
		
		Button BACKTOMAIN_BUTTON = new Button(DorW_COMPOSITE, SWT.NONE);
		BACKTOMAIN_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DorW_COMPOSITE.setVisible(false);
				GETBALANCE_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(true);
			}
		});
		BACKTOMAIN_BUTTON.setLocation(163, 182);
		BACKTOMAIN_BUTTON.setSize(108, 39);
		BACKTOMAIN_BUTTON.setText("\u8FD4\u56DE");
		BACKTOMAIN_BUTTON.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		
		
		//create a dialog to check the key
		CHECK_COMPOSITE = new Composite(parent, SWT.NONE);
		CHECK_COMPOSITE.setBounds(0, 0, 434, 186);
		
		KEY_NAME_TEXT = new Text(CHECK_COMPOSITE, SWT.READ_ONLY | SWT.CENTER);
		KEY_NAME_TEXT.setText("\u8BF7\u8F93\u5165\u5BC6\u7801");
		KEY_NAME_TEXT.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		KEY_NAME_TEXT.setLocation(150, 40);
		KEY_NAME_TEXT.setSize(120, 22);
		
		KEY_VALUE_TEXT = new Text(CHECK_COMPOSITE, SWT.BORDER | SWT.PASSWORD | SWT.CENTER);
		KEY_VALUE_TEXT.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		KEY_VALUE_TEXT.setLocation(150, 70);
		KEY_VALUE_TEXT.setSize(120, 22);
		
		Button KEYENSURE_BUTTON = new Button(CHECK_COMPOSITE, SWT.NONE);
		KEYENSURE_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(!KEY_VALUE_TEXT.getText().equals(key))
				{
					DorW_COMPOSITE.setVisible(false);
					GETBALANCE_COMPOSITE.setVisible(false);
					CHECK_COMPOSITE.setVisible(true);
					MAIN_COMPOSITE.setVisible(false);
					MessageDialog.openError(Display.getCurrent().getActiveShell(), "����", "��������ȷ���룡");
				}
				else
				{
					switch (choiceDorW) 
					{
					case 1:
						balance += choiceNum;
						MessageDialog.openInformation(Display.getCurrent().getActiveShell(), "�ɹ�", "�ɹ���ɲ�����");
						break;
					case 2:
						if(choiceNum > balance)
						{
							MessageDialog.openError(Display.getCurrent().getActiveShell(), "����", "�������㣡");
						}
						else
						{
							balance -= choiceNum;
							MessageDialog.openInformation(Display.getCurrent().getActiveShell(), "�ɹ�", "�ɹ���ɲ�����");
						}
						break;
					default:
						break;
					}
					BALANCE_VALUE_TEXT.setText(Integer.toString(balance));
					DorW_COMPOSITE.setVisible(false);
					GETBALANCE_COMPOSITE.setVisible(true);
					CHECK_COMPOSITE.setVisible(false);
					MAIN_COMPOSITE.setVisible(false);
				}
				
				KEY_VALUE_TEXT.setText("");
			}
		});
		KEYENSURE_BUTTON.setLocation(110, 110);
		KEYENSURE_BUTTON.setSize(80, 33);
		KEYENSURE_BUTTON.setText("\u786E\u5B9A");
		
		Button UNSURE_BUTTON = new Button(CHECK_COMPOSITE, SWT.NONE);
		UNSURE_BUTTON.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				DorW_COMPOSITE.setVisible(true);
				GETBALANCE_COMPOSITE.setVisible(false);
				CHECK_COMPOSITE.setVisible(false);
				MAIN_COMPOSITE.setVisible(false);
			}
		});
		UNSURE_BUTTON.setLocation(230, 110);
		UNSURE_BUTTON.setSize(80, 33);
		UNSURE_BUTTON.setText("\u8FD4\u56DE");
		

		return MAIN_COMPOSITE;
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Create the menu manager.
	 * @return the menu manager
	 */
	@Override
	protected MenuManager createMenuManager() {
		MenuManager menuManager = new MenuManager("menu");
		return menuManager;
	}

	/**
	 * Create the toolbar manager.
	 * @return the toolbar manager
	 */
	@Override
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBarManager = new ToolBarManager(style);
		return toolBarManager;
	}

	/**
	 * Create the status line manager.
	 * @return the status line manager
	 */
	@Override
	protected StatusLineManager createStatusLineManager() {
		StatusLineManager statusLineManager = new StatusLineManager();
		return statusLineManager;
	}

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			GUI window = new GUI();
			window.setBlockOnOpen(true);
			window.open();
			Display.getCurrent().dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Configure the shell.
	 * @param newShell
	 */
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("ATM");
	}

	/**
	 * Return the initial size of the window.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}
	

			
	
}
